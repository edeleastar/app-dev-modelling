package controllers;

import play.*;
import play.db.jpa.Blob;
import play.mvc.*;

import java.util.*;

import models.*;

public class HomeEdit extends Controller
{
	public static void uploadPicture(Long id, Blob picture)
	  {
	    User user = User.findById(id);
	    user.profilePicture = picture;
	    user.save();
	    Logger.info("saving picture");
	    Home.index();
	  } 
	
	public static void changeStatus(String statusText)
	  {
	    User user = Accounts.getLoggedInUser();
	    user.statusText = statusText;
	    user.save();
	    Logger.info("Status changed to " + statusText);
	    Home.index();
	  }
}