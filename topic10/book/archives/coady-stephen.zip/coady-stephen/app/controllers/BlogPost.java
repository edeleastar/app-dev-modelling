package controllers;

import java.util.List;

import models.Comment;
import models.Message;
import models.Post;
import models.User;
import play.Logger;
import play.mvc.Controller;

public class BlogPost  extends Controller
{
  public static void view(Long postid)
  {
	String userId = session.get("logged_in_userid");
	
	if(userId != null)
	{
		Logger.info("Post ID = " + postid);
		Post post = Post.findById(postid);
		render(post);
	}
	else
	{
		
		BlogPostPublic.view(postid);
		
	}
  }
  
  public static void newComment(String content, Long postid)
  {
	    User user = Accounts.getLoggedInUser();
	    Comment comment = new Comment (content);
	    comment.save();
	    Post post = Post.findById(postid);
	    post.comments.add(comment);
	    post.save();
	    user.save();
	    Logger.info ("Comment added: " + content);
	    view(postid);
  }

  public static void deletePost(Long postid)
  {    
    User user = Accounts.getLoggedInUser(); 
    Post post = Post.findById(postid);
    Logger.info("Request to delete title: " + post.title + "content" + post.content);
    
    user.posts.remove(post);

    user.save();
    post.delete();

    Blog.index();
  }
}