package controllers;

import java.util.Collections;
import java.util.List;





import models.Message;
import models.Post;
import models.User;
import play.Logger;
import play.mvc.Controller;

public class BlogPublic  extends Controller
{
  public static void index()
  {
    User user = Accounts.getLoggedInUser();
    Collections.reverse(user.posts);
    render(user);
  }

  public static void visit(Long id)
  {
    User user = User.findById(id);
    Logger.info("Just visiting the blog for " + user.firstName + ' ' + user.lastName);
    render(user);
  }
}