package models;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import play.Logger;
import play.db.jpa.Model;

@Entity	
public class Comment extends Model	
{	
 @Lob	
 public String content;	
 public String time;
 	
 public Comment(String content)
 {	
    this.content = content;
    Date date = new Date();
	DateFormat dateFormat = new SimpleDateFormat("HH:mm dd/MM/yyyy");
	time = dateFormat.format(date);
	Logger.info("time = " + time);
 }		 
 
}