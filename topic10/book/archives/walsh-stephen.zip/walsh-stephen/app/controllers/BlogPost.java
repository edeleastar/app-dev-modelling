package controllers;

import java.util.List;

import models.Message;
import models.Post;
import models.User;
import play.Logger;
import play.mvc.Controller;

public class BlogPost  extends Controller
{
  public static void view(Long postid)
  {
    Logger.info("Post ID = " + postid);
    Post post = Post.findById(postid);
    render(post);
  }
  
  public static void deletePost(Long postid)
  {
    User user = Accounts.getLoggedInUser();
       
    Post post = Post.findById(postid);
    Logger.info("Request to delete title: " + post.title + " content: " + post.content);
    
    user.posts.remove(post);
    
    user.save();
    post.delete();
    
    Blog.index();
  }
  
 
}