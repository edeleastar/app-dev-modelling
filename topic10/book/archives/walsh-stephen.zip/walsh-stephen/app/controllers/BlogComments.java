package controllers;

import java.util.List;

import models.Message;
import models.Post;
import models.User;
import models.Comment;
import play.Logger;
import play.mvc.Controller;

public class BlogComments  extends Controller
{
  
  public static void addComment(Long postid, String comment)
  {
  
	User user = Accounts.getLoggedInUser();
	Post post = Post.findById(postid);


	
	Comment comments = new Comment(user.firstName + " "+ user.lastName, comment, user.id);
	comments.save();
	post.comments.add(comments);
	post.save();
		
	Blog.index();
	
	
  }
}