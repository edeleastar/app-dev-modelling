package models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;

import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import play.db.jpa.Model;

@Entity
public class Comment extends Model {


	public String name;
	public long userId;
	public String content;
	public long date;

	public Comment(String name, String content, long id) {
		this.name = name;
		this.content = content;
		this.userId = id;
		this.date = System.currentTimeMillis();
	}

	public String toString() {
		return name;
	}
}