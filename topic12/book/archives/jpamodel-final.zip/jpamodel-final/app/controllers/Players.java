package controllers;

import java.util.List;

import models.Club;
import models.Player;
import play.Logger;
import play.mvc.Controller;

public class Players extends Controller
{      
  public static void index()
  {
    List<Player> players = Player.findAll();
    render (players);
  }
  
  public static void delete(Long id)
  {
    Player player = Player.findById(id);
    if (player != null)
    {
      if (player.club != null)
      {
        player.club.removePlayer(player);
        player.club.save();
      }
      player.delete();
    }
    index();
  }
  
  public static void addPlayer()
  {
    List<Club> clubs = Club.findAll();
    render(clubs);
  }

  public static void newPlayer(String name, String club)
  {
    Player player = new Player (name);
    Club theClub = Club.findByName(club);
    if (theClub != null)
    {
      theClub.addPlayer(player);
      theClub.save();
    }
    else
    {
      player.save();
    }
    index();
  }
  
  public static void editPlayer(Long id)
  {
    Player player = Player.findById(id);
    List<Club> clubs = Club.findAll();
    render(player, clubs);
  }
  
  public static void changePlayer(Long id, String name, String club)
  {
    Player player = Player.findById(id);
    Club theClub = Club.findByName(club);
    Logger.info ("CLub = " + club);
    player.name = name;
    if (null != theClub)
    {
      Logger.info ("changing club");
      player.club.players.remove(player);
      theClub.addPlayer(player);
      player.club = theClub;
      theClub.save();
    }
    player.save();
    index();
  }
}
